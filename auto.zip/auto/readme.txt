# ************************** #
1、使用ChromeSetup.exe 安装Google chrome 浏览器 
2、将driver_path修改为存放chromedriver.exe的文件夹
3、将key_word修改为要在google学术中搜索的关键词
4、将num修改为需要下载的pdf的数量
5、点击auto.exe 运行，下载地址为google chrome 默认下载地址，使用doi下载的文档存在程序所在文件夹

# @Author: qimeng
# @File  : readme.txt


